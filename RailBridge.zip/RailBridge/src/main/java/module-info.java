module com.mycompany.railbridge {
    requires javafx.controls;
    exports com.mycompany.railbridge;
}
