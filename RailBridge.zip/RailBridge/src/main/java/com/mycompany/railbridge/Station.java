/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.railbridge;

/**
 *
 * @author Rakib
 */
public class Station {
    private String stationName;
    private String city;
    
    public Station(String stationName, String city){
        this.stationName = stationName;
        this.city = city;
    }
    public String getStationName(){
        return stationName;
    }
}
