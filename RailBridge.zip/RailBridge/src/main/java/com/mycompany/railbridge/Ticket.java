/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.railbridge;

/**
 *
 * @author Rakib
 */
public class Ticket {
    private String ticketId;
    private Train train;
    private double price;
    
    public Ticket(String ticketId, Train train, double price){
        this.ticketId = ticketId;
        this.train = train;
        this.price = price;
    }
    
    @Override
    public String toString(){
        return ticketId + " | " + train.getTrainName() + " | $" + price;
    }
}
