/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.railbridge;

/**
 *
 * @author Rakib
 */
public class Train {
    private String trainName;
    private String route;
    private int totalSeats;
    
    public Train(String trainName, String route, int totalSeats){
        this.trainName = trainName;
        this.route = route;
        this.totalSeats = totalSeats;
    }
    public String getTrainName(){
        return trainName;
    }
    public int getTotalSeats(){
        return totalSeats;
    }
}
