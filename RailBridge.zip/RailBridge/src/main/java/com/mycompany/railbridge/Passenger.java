/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.railbridge;

import java.util.ArrayList;

/**
 *
 * @author Rakib
 */
public class Passenger extends User{
    private ArrayList<Ticket>myTickets = new ArrayList<>();
    
    public Passenger(String username, String password){
        super(username , password);
    }
    public void addTicket(Ticket t){
        myTickets.add(t);
    }
}
