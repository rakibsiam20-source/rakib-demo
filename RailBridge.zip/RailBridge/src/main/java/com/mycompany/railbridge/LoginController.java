/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.railbridge;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author Rakib
 */

public class LoginController {
    
   private static final String USER_FILE = "all_users.txt";

    public String verifyLogin(String username, String password) {
        File file = new File(USER_FILE);
        if (!file.exists()) return null; // No users registered yet

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
           
                String[] details = line.split(",");
                if (details.length >= 2) {
                    String storedUser = details[0].trim();
                    String storedPass = details[1].trim();
                    String storedRole = (details.length > 2) ? details[2] : "Passenger";

                    if (storedUser.equals(username.trim()) && storedPass.equals(password.trim())) {
                        return storedRole; 
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Login Error: " + e.getMessage());
        }
        return null;
    }
}