/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.railbridge;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Rakib
 */

import java.io.*;

public class FileHandler {

    private static final String USER_FILE = "all_users.txt";

    public static void registerUser(String username, String password, String role) throws Exception {
   
        if (username.contains(",") || password.contains(",")) {
            throw new Exception("Commas are not allowed in credentials.");
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(USER_FILE, true))) {
  
            bw.write(username.trim() + "," + password.trim() + "," + role);
            bw.newLine();
        } catch (IOException e) {
            throw new Exception("Database error: Could not save user.");
        }
    }
}