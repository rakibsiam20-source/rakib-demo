/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.railbridge;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Rakib
 */
public class BookingManager {
    private final int MAX_TICKETS_PER_USER = 4;
   private final Map<String, Integer> basePrices;
   
   
   public BookingManager(){
       basePrices = new HashMap<>();
       initializePrices();
   }
   // Inside BookingManager.java
private HashMap<String, Integer> seatAvailability = new HashMap<>();

public void initializeSeats() {
    seatAvailability.put("CHITTAGONG", 150);
    seatAvailability.put("SYLHET", 150);
    seatAvailability.put("COX'S BAZAR", 200);
    seatAvailability.put("DHAKA", 200);
    seatAvailability.put("RAJSHAHI", 150);
    seatAvailability.put("RANGPUR", 140);
    seatAvailability.put("DINAJPUR", 150);
    seatAvailability.put("KHULNA", 150);
    seatAvailability.put("JASHORE", 150);
    seatAvailability.put("PANCHAGARH", 200);
    seatAvailability.put("JAMALPUR", 70);
    seatAvailability.put("SREEMANGAL", 200);
}

public boolean bookSeat(String destination) {
    if (seatAvailability.containsKey(destination)) {
        int left = seatAvailability.get(destination);
        if (left > 0) {
            seatAvailability.put(destination, left - 1);
            return true;
        }
    }
    return false;
}
public void cancelSeat(String destination) {
    if (seatAvailability.containsKey(destination)) {
        int left = seatAvailability.get(destination);
        seatAvailability.put(destination, left + 1);
    }
}
public int getAvailableSeats(String destination){
    return seatAvailability.getOrDefault(destination, 0);
}

   void initializePrices(){
       basePrices.put("DHAKA", 410);
       basePrices.put("CHITTAGONG", 495);
       basePrices.put("SYLHET", 410);
       basePrices.put("RAJSHAHI", 450);
       basePrices.put("KHULNA", 640);
       basePrices.put("RANGPUR", 650);
       basePrices.put("DINAJPUR", 630);
       basePrices.put("JAMALPUR", 210);
       basePrices.put("PANCHAGARH", 740);
       basePrices.put("SREEMANGAL", 300);
       basePrices.put("COX'S BAZAR", 750);
       basePrices.put("JASHORE", 450);
   } 
   public double calculateTotalFare(String destination, String seatType, int currentTicketCount) throws Exception{
       if(currentTicketCount >= MAX_TICKETS_PER_USER){
           throw new Exception("Purchase Limit Reached: You cannot buy more than " + MAX_TICKETS_PER_USER + " tickets.");
       }
       if(!basePrices.containsKey(destination)){
           throw new Exception("Destination not found in the system.");
       }
       int basePrice = basePrices.get(destination);
       int additionalCharge = 0;
       
       switch(seatType.toUpperCase().trim()){
           case "AC SEAT": additionalCharge = 200;
           break;
           case "AC CABIN": additionalCharge = 400;
           break;
           case "GENERAL": additionalCharge = 0;
           break;
           default: System.out.println("Unknown seat type. Applying general price.");
       }
       return basePrice + additionalCharge;
   }
}
