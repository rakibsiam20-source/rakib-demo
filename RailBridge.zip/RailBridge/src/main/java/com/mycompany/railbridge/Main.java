/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Rakib
 */

package com.mycompany.railbridge;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main extends Application {

    private int ticketsBought = 0;
    private double sessionGrandTotal = 0.0;
    private final BookingManager bookingManager = new BookingManager();
    private final LoginController loginController = new LoginController();
    private String loggedInUser = "";
    
    // Lists to track current session for "Initial Condition" restoration
    private List<String> sessionRecords = new ArrayList<>();
    private List<String> sessionCities = new ArrayList<>(); 
    private List<Double> sessionFares = new ArrayList<>();

    @Override
    public void start(Stage primaryStage) {
        bookingManager.initializePrices();
        bookingManager.initializeSeats(); 
        showLoginScreen(primaryStage);
    }

    private void showLoginScreen(Stage stage) {
        // Full System Reset for Security
        ticketsBought = 0;
        sessionGrandTotal = 0.0;
        sessionRecords.clear();
        sessionCities.clear();
        sessionFares.clear();

        stage.setTitle("RailBridge - Secure Portal");
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(40));
        layout.setAlignment(Pos.CENTER);

        Label title = new Label("Railway Portal");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        TextField userField = new TextField(); userField.setPromptText("Username");
        PasswordField passField = new PasswordField(); passField.setPromptText("Password");

        Button loginBtn = new Button("Login");
        loginBtn.setMaxWidth(Double.MAX_VALUE);
        loginBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold;");

        Button registerBtn = new Button("Register New Account");
        registerBtn.setMaxWidth(Double.MAX_VALUE);

        // --- STRICT LOGIN SECURITY ---
        loginBtn.setOnAction(e -> {
            String u = userField.getText().trim();
            String p = passField.getText().trim();

            if (u.isEmpty() || p.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Security Guard", "Login denied: Fields cannot be empty.");
                return; 
            }

            if (loginController.verifyLogin(u, p) != null) {
                loggedInUser = u;
                showBookingScreen(stage);
            } else {
                showAlert(Alert.AlertType.ERROR, "Access Denied", "No matching user found.");
            }
        });

        registerBtn.setOnAction(e -> {
            if(userField.getText().isEmpty()) return;
            try {
                FileHandler.registerUser(userField.getText(), passField.getText(), "Passenger");
                showAlert(Alert.AlertType.INFORMATION, "Success", "Registration Complete! Please Login.");
            } catch (Exception ex) { showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage()); }
        });

        layout.getChildren().addAll(title, userField, passField, loginBtn, registerBtn);
        stage.setScene(new Scene(layout, 380, 450));
        stage.show();
    }

    private void showBookingScreen(Stage stage) {
        stage.setTitle("Booking Dashboard");
        VBox layout = new VBox(12);
        layout.setPadding(new Insets(25));

        Label welcome = new Label("User: " + loggedInUser);
        Label statusLabel = new Label("Status: Ready to Book");
        Label seatInfoLabel = new Label("Select destination to see seats.");
        seatInfoLabel.setTextFill(Color.DARKBLUE);

        String[] cities = {"DHAKA", "CHITTAGONG", "SYLHET", "RAJSHAHI", "KHULNA", "COX'S BAZAR", "RANGPUR", "JAMALPUR", "SREEMANGAL", "JASHORE", "PANCHAGARH", "DINAJPUR"};
        ChoiceBox<String> fromBox = new ChoiceBox<>(); fromBox.getItems().addAll(cities);
        ChoiceBox<String> toBox = new ChoiceBox<>(); toBox.getItems().addAll(cities);
        
        // --- DYNAMIC SEAT AVAILABILITY (Previous code style) ---
        toBox.setOnAction(e -> {
            if (toBox.getValue() != null) {
                int s = bookingManager.getAvailableSeats(toBox.getValue());
                seatInfoLabel.setText("Seats available for " + toBox.getValue() + ": " + s);
            }
        });

        ChoiceBox<String> typeBox = new ChoiceBox<>();
        typeBox.getItems().addAll("General", "AC Seat", "AC Cabin");
        typeBox.setValue("General");

        Button confirmBtn = new Button("Confirm Purchase");
        confirmBtn.setMaxWidth(Double.MAX_VALUE);
        confirmBtn.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; -fx-font-weight: bold;");

        Button cancelBtn = new Button("Cancel & Delete Last Ticket");
        cancelBtn.setMaxWidth(Double.MAX_VALUE);
        cancelBtn.setStyle("-fx-background-color: #e67e22; -fx-text-fill: white;");

        Button historyBtn = new Button("View Records & Grand Total");
        historyBtn.setMaxWidth(Double.MAX_VALUE);

        Button logoutBtn = new Button("Logout");

        // --- CONFIRM: UPDATE DATA ---
        confirmBtn.setOnAction(e -> {
            try {
                if (ticketsBought >= 4) {
                    showAlert(Alert.AlertType.WARNING, "Limit", "Max 4 per session.");
                    return;
                }
                String t = toBox.getValue();
                if (t == null || t.equals(fromBox.getValue())) return;

                if (bookingManager.bookSeat(t)) {
                    double fare = bookingManager.calculateTotalFare(t, typeBox.getValue(), ticketsBought);
                    
                    ticketsBought++;
                    sessionGrandTotal += fare;
                    String entry = String.format("%s to %s (%s) - %.2f BDT", fromBox.getValue(), t, typeBox.getValue(), fare);
                    
                    sessionRecords.add(entry);
                    sessionCities.add(t);
                    sessionFares.add(fare);
                    
                    saveToFile(loggedInUser, entry);
                    
                    statusLabel.setText("Ticket #" + ticketsBought + " Confirmed.");
                    seatInfoLabel.setText("Updated seats for " + t + ": " + bookingManager.getAvailableSeats(t));
                }
            } catch (Exception ex) { showAlert(Alert.AlertType.ERROR, "Error", ex.getMessage()); }
        });

        // --- CANCEL: RETURN TO INITIAL CONDITION ---
        cancelBtn.setOnAction(e -> {
            if (ticketsBought > 0) {
                int lastIdx = sessionRecords.size() - 1;
                String cityToRestore = sessionCities.get(lastIdx);
                String recordToDelete = sessionRecords.get(lastIdx);
                double fareToSubtract = sessionFares.get(lastIdx);

                // 1. Restore Seat Count (+1)
                bookingManager.cancelSeat(cityToRestore); 
                
                // 2. Clear Data from Text File
                removeRecordFromFile(loggedInUser, recordToDelete); 
                
                // 3. Reset Session Counters
                sessionRecords.remove(lastIdx);
                sessionCities.remove(lastIdx);
                sessionFares.remove(lastIdx);
                
                ticketsBought--;
                sessionGrandTotal -= fareToSubtract;

                // Live Feedback of the "Change"
                statusLabel.setText("Action: Canceled. Ticket count returned to " + ticketsBought);
                seatInfoLabel.setText("Seat returned! Current " + cityToRestore + " seats: " + bookingManager.getAvailableSeats(cityToRestore));
                
                showAlert(Alert.AlertType.WARNING, "Cancellation Success", 
                        "Data purged from file.\nSeat count returned to initial state for: " + cityToRestore);
            }
        });

        // --- HISTORY & GRAND TOTAL ---
        historyBtn.setOnAction(e -> {
            String hist = readFromFile(loggedInUser);
            showAlert(Alert.AlertType.INFORMATION, "Permanent Purchase Log", 
                      hist + "\n\n------------------------\n" +
                      "Tickets in Session: " + ticketsBought + "\n" +
                      "GRAND TOTAL: " + sessionGrandTotal + " BDT");
        });

        logoutBtn.setOnAction(e -> showLoginScreen(stage));

        layout.getChildren().addAll(welcome, statusLabel, seatInfoLabel, fromBox, toBox, typeBox, confirmBtn, cancelBtn, historyBtn, logoutBtn);
        stage.setScene(new Scene(layout, 420, 650));
    }

    // --- FILE I/O OPERATIONS ---
    private void saveToFile(String user, String record) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("ticket_history.txt", true))) {
            bw.write(user + "|" + record);
            bw.newLine();
        } catch (IOException e) { e.printStackTrace(); }
    }

    private void removeRecordFromFile(String user, String recordToDelete) {
        List<String> updatedLines = new ArrayList<>();
        String target = user + "|" + recordToDelete;
        try (BufferedReader br = new BufferedReader(new FileReader("ticket_history.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.equals(target)) updatedLines.add(line);
            }
        } catch (IOException e) { e.printStackTrace(); }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("ticket_history.txt"))) {
            for (String l : updatedLines) {
                bw.write(l);
                bw.newLine();
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    private String readFromFile(String user) {
        StringBuilder sb = new StringBuilder("Records for " + user + ":\n");
        try (BufferedReader br = new BufferedReader(new FileReader("ticket_history.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith(user + "|")) {
                    sb.append("• ").append(line.split("\\|")[1]).append("\n");
                }
            }
        } catch (IOException e) { return "No records."; }
        return sb.toString();
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void main(String[] args) { launch(args); }
}